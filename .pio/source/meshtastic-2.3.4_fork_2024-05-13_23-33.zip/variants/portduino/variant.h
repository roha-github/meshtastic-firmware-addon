#define HAS_SCREEN 1
#define CANNED_MESSAGE_MODULE_ENABLE 1
#define HAS_GPS 1
#define MAX_NUM_NODES settingsMap[maxnodes]
#define RADIOLIB_GODMODE 1
