#pragma once

/*
 * To developers:
 *   Use this to enable / disable features in your module that you don't want to risk checking into GitHub.
 *
 */

// Enable development more for StoreForwardModule
bool StoreForward_Dev = false;