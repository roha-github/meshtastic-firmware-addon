#ifndef OLEDDISPLAYFONTSRU_h
#define OLEDDISPLAYFONTSRU_h

#ifdef ARDUINO
#include <Arduino.h>
#elif __MBED__
#define PROGMEM
#endif

extern const uint8_t ArialMT_Plain_10_RU[] PROGMEM;
#endif