#pragma once

#include "configuration.h"
#include <Arduino.h>
#include <functional>

bool initEthernet();
bool isEthernetAvailable();
