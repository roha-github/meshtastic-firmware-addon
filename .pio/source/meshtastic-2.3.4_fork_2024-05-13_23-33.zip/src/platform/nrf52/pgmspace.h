#pragma once

// dummy file to keep old arduino code happy
#define PROGMEM
#define pgm_read_byte(addr) (*((unsigned const char *)addr))