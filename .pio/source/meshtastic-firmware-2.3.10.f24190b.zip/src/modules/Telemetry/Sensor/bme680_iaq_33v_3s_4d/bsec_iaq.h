#if !MESHTASTIC_EXCLUDE_ENVIRONMENTAL_SENSOR

#include <stdint.h>

extern const uint8_t bsec_config_iaq[1974];

#endif